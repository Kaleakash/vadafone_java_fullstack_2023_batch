package com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3demoappApplicationTests {

	@Test
	void contextLoads() {
	}

}
